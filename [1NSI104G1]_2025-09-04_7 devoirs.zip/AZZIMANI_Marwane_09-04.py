def identification(i, j):
   
    print(f"La pièce située en ({i}, {j}) est un fou.")

def move_piece(plateau, joueur, start_x, start_y, end_x, end_y):
    """
    Déplace le fou s'il respecte les règles du jeu d'échecs.

    Paramètres :
    - plateau : tableau représentant l'échiquier
    - start_x, start_y : position de départ du fou
    - end_x, end_y : position d'arrivée souhaitée
    """
    # Vérifier si le mouvement est bien en diagonale
    if not abs(end_x - start_x) == abs(end_y - start_y):
        print("Mouvement invalide : un fou ne peut se déplacer que sur les diagonales.")
        return False
    else :
        print(f"Déplacement du fou de ({start_x}, {start_y}) vers ({end_x}, {end_y}) validé.")
        # Ici, on pourrait ajouter une vérification pour s'assurer qu'il n'y a pas d'obstacles
        # sur le chemin, et que la case d'arrivée est vide ou contient une pièce adverse.
        if not deplacement_fou(plateau, joueur, start_x, start_y, end_x, end_y):
            return False
        if not peut_manger(plateau, joueur, end_x, end_y):
            return False
        
    return True



# faire une boucle pour vérifier si ya pas une pièce sur le trajet ( mouvement interdi ou autorisé), param

# Ajout de la vérification des obstacles
def deplacement_fou(plateau, joueur, depart_x, depart_y, arrivee_x, arrivee_y):
    """
    Vérifie si le fou peut se déplacer sans obstacle en utilisant 4 boucles séparées .
    """
    if abs(arrivee_x - depart_x) == abs(arrivee_y - depart_y):  # Vérifier la diagonale
        
        # Déplacemnt en haut à droite
        if arrivee_x > depart_x and arrivee_y > depart_y:
            x, y = depart_x + 1, depart_y + 1
            while x < arrivee_x and y < arrivee_y:
                if plateau[x][y] != ' ':
                    print("Mouvement interdit : une pièce bloque le chemin.")
                    return False
                x += 1
                y += 1

        # Déplacemnt en haut à gauche
        elif arrivee_x > depart_x and arrivee_y < depart_y:
            x, y = depart_x + 1, depart_y - 1
            while x < arrivee_x and y > arrivee_y:
                if plateau[x][y] != ' ':
                    print("Mouvement interdit : une pièce bloque le chemin.")
                    return False
                x += 1
                y -= 1

        # Déplacemnt en bas à droite
        elif arrivee_x < depart_x and arrivee_y > depart_y:
            x, y = depart_x - 1, depart_y + 1
            while x > arrivee_x and y < arrivee_y:
                if plateau[x][y] != ' ':
                    print("Mouvement interdit : une pièce bloque le chemin.")
                    return False
                x -= 1
                y += 1

        # Déplacemnt en bas à gauche
        elif arrivee_x < depart_x and arrivee_y < depart_y:
            x, y = depart_x - 1, depart_y - 1
            while x > arrivee_x and y > arrivee_y:
                if plateau[x][y] != ' ':
                    print("Mouvement interdit : une pièce bloque le chemin.")
                    return False
                x -= 1
                y -= 1

    return True    


# Ajout de la vérification pour manger seulement les pièces ennemies
def peut_manger(plateau, joueur, arrivee_x, arrivee_y):
    """
    Vérifie si la case d’arrivée contient une pièce ennemie ou est vide.
    - joueur : 'blanc' ou 'noir'
    - plateau : représentation de l’échiquier, chaque case contient soit ' ', soit une pièce.
    Convention : 
    - les pièces blanches commencent par 'b' (ex: 'bF' pour fou blanc)
    - les pièces noires commencent par 'n' (ex: 'nF' pour fou noir)
    """
    piece = plateau[arrivee_x][arrivee_y]
    
    if piece == ' ':
        return True  # La case est vide, donc on peut y aller

    if joueur == 'blanc' and piece.startswith('n'):
        return True  # C'est une pièce noire, donc ennemie

    if joueur == 'noir' and piece.startswith('b'):
        return True  # C'est une pièce blanche, donc ennemie

    print("Mouvement interdit : vous ne pouvez pas manger votre propre pièce.")
    return False
   