#Codage piece Tour groupe ROXY


plateau = ['RNBKQBNR',
          'PPPPPPPP',
          '        ',
          '        ',
          '        ',
          '        ',
          'pppppppp',
          'rnbkqbnr']




def identification(i, j):
    print('La pièce est une tour')

def move_piece(plateau,joueur,i_depart,j_depart,i_arrivee,j_arrivee):
    
    if verifier_deplacement(i_depart,j_depart,i_arrivee,j_arrivee):
    
        if verifier_piece_trajet(plateau,joueur,i_depart,j_depart,i_arrivee,j_arrivee):
            return True
    
    

    
print("fonction à coder")    

def verifier_deplacement(i_depart,j_depart,i_arrivee,j_arrivee):
    

    if (i_arrivee == i_depart and j_arrivee != j_depart) or  (j_arrivee == j_depart and i_depart != i_arrivee):
        print("c'est bon") 
        return True 
    else :
        print("ce mouvement n'est pas disponnible")
        return False

    # on vérifie que soit on est la même ligne, soit on est sur la même colonne


def verifier_piece_trajet(plateau,joueur,i_depart,j_depart,i_arrivee,j_arrivee):         #cette fonction verifie le trajet de la piece 
    
    if joueur == 'b' and plateau[i_depart][j_depart] != 'r': 
        return False
    if joueur == 'w' and plateau[i_depart][j_depart] != 'R':
        return False
    
    if j_arrivee > j_depart : 
        for j in range(j_depart +1 ,j_arrivee-1):
           piece = plateau[i_depart][j]
           if piece != ' ':
              return False


    if j_arrivee < j_depart : 
        for j in range(j_depart -1, j_arrivee, -1):
          piece = plateau[i_depart][j]
          if piece != ' ':
              return False

    
    if i_arrivee > i_depart : 
        for i in range(i_depart +1 ,i_arrivee-1):
                piece = plateau[j_depart][i]
                if piece != ' ':
                    return False

    if i_arrivee < i_depart : 
        for i in range(i_depart -1, i_arrivee +1):
            piece = plateau[j_depart][i]
            if piece != ' ':
                    return False


    return True


def manger(plateau,joueur,i_depart,j_depart,i_arrivee,j_arrivee):          #cette fonction permet de manger un pion avec des sous fonction qui la "definisse"
    
    if verifie_piece_adverse(plateau,joueur,i_depart,j_depart,i_arrivee,j_arrivee):         #cette fonction verifie que la piece qui peux etre manger est bien une piece adverse
    
        if manger_piece(plateau ,joueur , i_depart, j_depart, i_arrivee,j_arrivee):
            print("Vous avez jouer")
        for ligne in plateau:
            print(ligne)
        else:
            print("Vous ne pouvez pas faire ca")
    return True


def verifie_piece_adverse(plateau,joueur,i_depart,j_depart,i_arrivee,j_arrivee):             #cette fonction verifie que la piece qui peux etre manger est bien une piece adverse
  
    if joueur == 'b' and plateau[i_arrivee][j_arrivee] in 'RNBKQP ' :
        return True
    else: 
        print("La piece ne peux pas etre mangée")                      #si la piece n'est pas une piece adverse alors elle ne peux pas etre mangee
        return False
    


def manger_piece(plateau,joueur,i_depart,j_depart,i_arrivee,j_arrivee):        #fonction pour mangee la pieceadverse
    
    
    if verifie_piece_adverse(plateau,joueur,i_depart,j_depart,i_arrivee,j_arrivee):

    
        plateau[i_depart][i_arrivee] == [j_depart][j_arrivee]       
        plateau[i_depart][j_depart] == ''                       # la case est maintenant vide vue que le pion a bouger

        print(f"La pièce {plateau[i_depart][i_arrivee]} a ete mangee")
        return True  # La pièce a été mangée avec succès
    else:
        print("Aucune pièce adverse à manger")
        return False  # Il n'y a pas de pièce adverse à manger
    


print(plateau)