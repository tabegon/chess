def identification(i, j):
    print("La pièce est une dame")

def is_allied_piece(player_turn, destination_piece):
    """
    Vérifie si la pièce à la destination appartient au même joueur (alliée).
    """
    if player_turn == 'w':
        return destination_piece.isupper()  # Les pièces blanches sont en majuscule (alliées)
    else:
        return destination_piece.islower()  # Les pièces noires sont en minuscule (alliées)


def is_king(player_turn, destination_piece):
    """
    Vérifie si la pièce à la destination est le roi de l'adversaire.
    """
    if player_turn == 'w':
        return destination_piece == 'k'  # Le roi noir est 'k'
    else:
        return destination_piece == 'K'  # Le roi blanc est 'K'



def move_piece(board, player_turn, i_origine, j_origine, i_clic, j_clic):
    """
    Vérifie si le déplacement de la dame est valide et le réalise.
    La dame peut se déplacer horizontalement, verticalement et en diagonale.
    Elle peut également manger une pièce ennemie, sauf le roi et les pièces alliées.
    """

    # La dame peut se déplacer en ligne droite (horizontalement ou verticalement) ou en diagonale
    # Vérification du mouvement vertical (même colonne)
    if i_origine == i_clic:
        direction = 1 if j_clic > j_origine else -1
        for j in range(j_origine + direction, j_clic, direction):
            if board[j][i_origine] != ' ':
                return False  # Il y a une pièce qui bloque le chemin

    # Vérification du mouvement horizontal (même ligne)
    elif j_origine == j_clic:
        direction = 1 if i_clic > i_origine else -1
        for i in range(i_origine + direction, i_clic, direction):
            if board[j_origine][i] != ' ':
                return False  # Il y a une pièce qui bloque le chemin

    # Vérification du mouvement diagonal
    elif abs(i_origine - i_clic) == abs(j_origine - j_clic):
        direction_i = 1 if i_clic > i_origine else -1
        direction_j = 1 if j_clic > j_origine else -1
        i, j = i_origine + direction_i, j_origine + direction_j
        while i != i_clic and j != j_clic:
            if board[j][i] != ' ':
                return False  # Il y a une pièce qui bloque le chemin
            i += direction_i
            j += direction_j

    else:
        return False  # La dame ne peut pas se déplacer ainsi (mouvement non valide)

    # Vérification si la case de destination est occupée par une pièce alliée ou le roi
    destination_piece = board[j_clic][i_clic]

    # Vérification du roi : on ne peut pas manger le roi
    if is_king(player_turn, destination_piece):
        return False  # Le roi de l'adversaire ne peut pas être mangé

    # Vérification des pièces alliées : on ne peut pas manger une pièce alliée
    if is_allied_piece(player_turn, destination_piece):
        return False  # On ne peut pas manger une pièce alliée

    # Condition pour interdire à la dame de se capturer elle-même :
    if (player_turn == 'w' and destination_piece == 'Q') or (player_turn == 'b' and destination_piece == 'q'):
        return False  # La dame du joueur ne peut pas capturer sa propre dame

    # Si la destination est vide ou occupée par une pièce ennemie (autre que le roi ou une pièce alliée),
    # la dame peut se déplacer et capturer la pièce ennemie
    if destination_piece != ' ' and not is_allied_piece(player_turn, destination_piece):
        return True

    # Si la case de destination est vide ou si la pièce ennemie est capturable, le mouvement est autorisé
    return True
