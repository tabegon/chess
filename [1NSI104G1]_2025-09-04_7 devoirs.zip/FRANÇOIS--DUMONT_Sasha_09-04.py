# Amelie annedouche
# Sasha FD
# NOA CS
# Louise Lekens

# Jeu d'échec : le cavalier

def identification(i, j):
    print('La pièce est un cavalier')


def savoir_couleur_de_piece(piece):
    """
    permet de savoir si la piece est noir ou blanche
    @param piece : categorie de la piece
    @return : N ou n pour la couleur de la piece
    """
    liste_blanc = ['R', 'N', 'B', 'K', 'Q', 'P']
    liste_noir = ['r', 'n', 'b', 'k', 'q', 'p']

    if piece in liste_blanc:
        return 'N'
    elif piece in liste_noir:
        return 'n'


def move_verifie(j_depart, i_depart, j_arrivee, i_arrivee):
    """
    Vérifie si le déplacement est possible, c'est-à-dire si la case choisie
    correspond bien aux mouvements que la pièce doit faire, c'est-à-dire un L.
    @param i_arrivee, i_depard, j_arrivee, j_depard : booleen
    @return : bool
    """
    if i_arrivee == i_depart + 1 and j_arrivee == j_depart + 2:
        return True
    elif i_arrivee == i_depart + 2 and j_arrivee == j_depart + 1:
        return True

    elif i_arrivee == i_depart + 1 and j_arrivee == j_depart - 2:
        return True
    elif i_arrivee == i_depart + 2 and j_arrivee == j_depart - 1:
        return True

    elif i_arrivee == i_depart - 1 and j_arrivee == j_depart + 2:
        return True
    elif i_arrivee == i_depart - 2 and j_arrivee == j_depart + 1:
        return True

    elif i_arrivee == i_depart - 1 and j_arrivee == j_depart - 2:
        return True
    elif i_arrivee == i_depart - 2 and j_arrivee == j_depart - 1:
    	return True
    else :
    	return False


def move_piece(plateau, joueur, i_depart, j_depart, i_arrivee, j_arrivee):
    """
    Gère les déplacements de la pièce, on appelle toute les autre fonction pour
    verifié si le cavalier ne va pas sur un piece de sa couleur et si c est à
    lui de jouer.
    Verifie que toute les fonctions return true, si une fonction
    returne false alors le deplacement est refusé
    @param plateau, joueur, i_arrivee, i_depard, j_arrivee, j_depard : booleen
    @return : bool
    """
    liste_blanc = ['R', 'N', 'B', 'K', 'Q', 'P']
    liste_noir = ['r', 'n', 'b', 'k', 'q', 'p']

    piece_depart = plateau[j_depart][i_depart]
    piece_arrivee = plateau[j_arrivee][i_arrivee]

    # Vérifier que la pièce appartient au joueur sinon return false
    if joueur == 'w' and piece_depart not in liste_blanc:
        return False
    if joueur == 'b' and piece_depart not in liste_noir:
        return False

    # Vérifier que le mouvement est celui d’un cavalier
    if not move_verifie(i_depart, j_depart, i_arrivee, j_arrivee):
        return False

    # Vérifier si la case d’arrivée est vide ou contient une pièce adverse
    if piece_arrivee == ' ':
        return True

    couleur_depart = savoir_couleur_de_piece(piece_depart)
    couleur_arrivee = savoir_couleur_de_piece(piece_arrivee)

    if couleur_depart != couleur_arrivee:
        return True

    return False
