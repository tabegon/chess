#Codage du pion par Rochette Clément, Delerin Clément, Miquel Nolan, Rigaud Antoine et Boutin Urian
def identification(i, j):
    """
    Affiche l'identification de la pièce sélectionnée.
    @param i: Position en colonne de la pièce
    @param j: Position en ligne de la pièce
    """
    print("La pièce est un pion")

def move_piece(board, player_turn, i_origine, j_origine, i_clic, j_clic):
    """
    Vérifie si le déplacement du pion est valide.
    @param board: Échiquier sous forme de liste de listes
    @param player_turn: Couleur du joueur actuel 'w' ou 'b'
    @param i_origine: Colonne de départ du pion
    @param j_origine: Ligne de départ du pion
    @param i_clic: Colonne de destination
    @param j_clic: Ligne de destination
    @return: True si le mouvement est valide, False sinon
    """
    if player_turn == 'w':
        direction = -1 
    else:
        direction = 1 
    if player_turn == 'b':
        start_row = 1
    else:
        start_row = 6  
    
    #Les déplacements d'une case (vers l'avant)
    if i_clic == i_origine and j_clic == j_origine + direction and board[j_clic][i_clic] == ' ':
        return True

    if i_clic == i_origine and j_clic == j_origine + 2 * direction and j_origine == start_row:  #Les déplacements de deux cases (vers l'avant) si c'est le premier mouvement
        #On vérifie si les cases intermédiaires sont vides
        if board[j_origine + direction][i_origine] == ' ' and board[j_clic][i_clic] == ' ':
            return True
    #On capture en diagonale c'est à dire que le pion avance d'une ligne et se déplace d'une colonne
    
    if abs(i_clic - i_origine) == 1 and j_clic == j_origine + direction:
        #On vérifie qu'une pièce ennemie est bien présente sur la case d'arrivée
        if board[j_clic][i_clic] != ' ' and (board[j_clic][i_clic] == board[j_clic][i_clic].lower()) == (player_turn == 'b'):
            return True
    return False    #Par contres si aucune condition n'est remplie, le déplacement est invalide
